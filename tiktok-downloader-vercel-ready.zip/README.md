```markdown
# TikTok Downloader - Daus Tools

Sebuah alat web modern untuk mengunduh video, foto, dan audio dari TikTok tanpa watermark. Dibangun dengan tampilan premium "blue ice" yang elegan dan fungsionalitas yang kuat.

## Fitur Utama

- ✅ **Download Video HD**: Ambil video TikTok tanpa watermark dalam kualitas tinggi
- 🖼️ **Download Foto/Gambar**: Unduh semua foto dari postingan galeri TikTok
- 🎵 **Download Audio**: Ekstrak lagu original dari video TikTok
- 📊 **Metadata Lengkap**: Tampilkan statistik (views, likes, comments, shares)
- 👤 **Info Kreator**: Tampilkan profil dan username pembuat konten
- 🎨 **Tema Blue Ice**: Desain modern dengan efek glassmorphism
- 📱 **Responsive**: Cocok untuk desktop dan perangkat mobile
- 🔄 **Tanpa Refresh**: Pengalaman pengguna tanpa reload halaman

## Teknologi yang Digunakan

- HTML5, CSS3, JavaScript ES6+
- Fetch API untuk komunikasi dengan server
- CSS Grid & Flexbox untuk layout
- Font Awesome untuk ikon
- Manifest.json untuk Progressive Web App (PWA)

## Struktur Proyek

```
tiktok-downloader/
├── public/
│   ├── index.html
│   ├── favicon.ico
│   └── manifest.json
├── src/
│   ├── index.js
│   ├── components/
│   ├── services/
│   ├── utils/
│   └── assets/
└── styles/
    ├── global.css
    ├── components/
    └── themes/
```

## Cara Menjalankan

1. Clone repositori ini
2. Buka file `public/index.html` di browser kamu
3. Tempel URL TikTok dan klik "Download"

> Catatan: Aplikasi ini bergantung pada API eksternal. Jika terjadi kegagalan, coba periksa koneksi internet atau format URL.

## Kontribusi

Kontribusi sangat diterima! Silakan buat pull request atau issue jika kamu menemukan bug atau memiliki ide untuk fitur baru.

## Lisensi

Proyek ini dilisensikan di bawah MIT License - lihat file [LICENSE](LICENSE) untuk detail lengkapnya.

---

Made with ❤️ by **Firdaus 7B**
```