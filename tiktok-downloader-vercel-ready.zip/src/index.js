import { fetchTikTokData } from './services/apiService.js';
import { downloadFile, copyToClipboard, shareContent } from './services/downloadService.js';
import { validateUrl } from './utils/validators.js';
import { formatNumber } from './utils/helpers.js';

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('downloadForm');
    const urlInput = document.getElementById('tiktokUrl');
    const downloadBtn = document.getElementById('downloadBtn');
    const loadingSection = document.getElementById('loadingSection');
    const resultSection = document.getElementById('resultSection');
    const errorMessage = document.getElementById('errorMessage');
    const authorInfo = document.getElementById('authorInfo');
    const videoTitle = document.getElementById('videoTitle');
    const previewContainer = document.getElementById('previewContainer');
    const videoStats = document.getElementById('videoStats');
    const musicInfo = document.getElementById('musicInfo');
    const downloadButtons = document.getElementById('downloadButtons');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const url = urlInput.value.trim();

        if (!validateUrl(url)) {
            showError('URL tidak valid! Pastikan formatnya benar.');
            return;
        }

        showLoading(true);
        hideError();

        try {
            const data = await fetchTikTokData(url);
            showLoading(false);
            displayResult(data);
        } catch (error) {
            showLoading(false);
            showError(error.message);
        }
    });

    function showLoading(show) {
        loadingSection.style.display = show ? 'flex' : 'none';
        downloadBtn.disabled = show;
        downloadBtn.innerHTML = show ? '<span class="spinner-icon"></span> Memproses...' : '<i class="fas fa-download"></i> Download';
    }

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.style.display = 'block';    }

    function hideError() {
        errorMessage.style.display = 'none';
    }

    function displayResult(data) {
        // Display author info
        authorInfo.innerHTML = `
            <img src="${data.author.avatar}" alt="Avatar" class="author-avatar" onerror="this.src='./assets/images/placeholder.jpg';">
            <div class="author-details">
                <h3>${data.author.nickname}</h3>
                <span>${data.author.unique_id}</span>
            </div>
        `;

        // Display video title
        videoTitle.textContent = data.desc;

        // Display preview (video or images)
        previewContainer.innerHTML = '';
        if (data.images && data.images.length > 0) {
            previewContainer.innerHTML = `<img src="${data.images[0]}" alt="Preview" class="preview-image">`;
        } else if (data.play_url) {
            previewContainer.innerHTML = `<video src="${data.play_url}" controls class="video-player"></video>`;
        }

        // Display stats
        videoStats.innerHTML = `
            <div class="stat-item">
                <strong>${formatNumber(data.stats.play_count)}</strong>
                <span>Views</span>
            </div>
            <div class="stat-item">
                <strong>${formatNumber(data.stats.digg_count)}</strong>
                <span>Likes</span>
            </div>
            <div class="stat-item">
                <strong>${formatNumber(data.stats.comment_count)}</strong>
                <span>Komentar</span>
            </div>
            <div class="stat-item">
                <strong>${formatNumber(data.stats.share_count)}</strong>
                <span>Share</span>
            </div>
        `;

        // Display music info
        if (data.music) {
            musicInfo.innerHTML = `                <div class="music-title">${data.music.title}</div>
                <div class="music-author">by ${data.music.author}</div>
            `;
        }

        // Generate download buttons
        let buttonsHTML = '';

        // Video download
        if (data.play_url) {
            buttonsHTML += `
                <button class="download-btn" onclick="downloadFile('${data.play_url}', 'tiktok-${data.id}.mp4')">
                    <i class="fas fa-video"></i> Video HD
                </button>
            `;
        }

        // Image downloads
        if (data.images && data.images.length > 0) {
            data.images.forEach((img, index) => {
                buttonsHTML += `
                    <button class="download-btn" onclick="downloadFile('${img}', 'tiktok-${data.id}-foto${index+1}.jpg')">
                        <i class="fas fa-image"></i> Foto ${index+1}
                    </button>
                `;
            });
        }

        // Music download
        if (data.music && data.music.play_url) {
            buttonsHTML += `
                <button class="download-btn" onclick="downloadFile('${data.music.play_url}', 'tiktok-music-${data.music.id}.mp3')">
                    <i class="fas fa-music"></i> Audio
                </button>
            `;
        }

        // Additional utility buttons
        buttonsHTML += `
            <button class="download-btn" onclick="copyToClipboard('${data.play_url || data.images[0]}')">
                <i class="fas fa-copy"></i> Copy Link
            </button>
            <button class="download-btn" onclick="shareContent('${data.desc}', '${data.play_url || data.images[0]}')">
                <i class="fas fa-share-alt"></i> Share
            </button>
        `;

        downloadButtons.innerHTML = buttonsHTML;
        resultSection.style.display = 'block';
                // Scroll to results
        resultSection.scrollIntoView({ behavior: 'smooth' });
    }

    // Make helper functions available globally for inline onclick handlers
    window.downloadFile = downloadFile;
    window.copyToClipboard = copyToClipboard;
    window.shareContent = shareContent;

    // Focus input on load
    urlInput.focus();
});