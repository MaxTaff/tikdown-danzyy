// services/apiService.js
export async function fetchTikTokData(url) {
    try {
        const response = await fetch('https://api-faa.my.id/faa/tiktok', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url: url })
        });

        if (!response.ok) {
            throw new Error(`Server API merespons dengan status ${response.status}`);
        }

        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Gagal mengambil data dari TikTok');
        }

        if (!data.data) {
            throw new Error('Data TikTok tidak ditemukan dalam respons');
        }

        return data.data;
    } catch (error) {
        if (error.name === 'TypeError' && error.message.includes('fetch')) {
            throw new Error('Gagal terhubung ke server. Periksa koneksi internet anda.');
        }
        throw error;
    }
}