// services/downloadService.js
export function downloadFile(url, filename) {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

export function copyToClipboard(text) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text)
            .then(() => {
                alert('Link berhasil disalin!');
            })
            .catch(err => {
                console.error('Gagal menyalin ke clipboard: ', err);
                fallbackCopyTextToClipboard(text);
            });
    } else {
        fallbackCopyTextToClipboard(text);
    }
}

function fallbackCopyTextToClipboard(text) {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.setAttribute('readonly', '');
    textArea.style.position = 'absolute';
    textArea.style.left = '-9999px';
    document.body.appendChild(textArea);
    textArea.select();
    try {
        const successful = document.execCommand('copy');
        if (successful) {
            alert('Link berhasil disalin!');
        } else {
            prompt('Copy manually:', text);
        }
    } catch (err) {
        console.error('Fallback: Oops, unable to copy', err);
        prompt('Copy manually:', text);
    }
    document.body.removeChild(textArea);
}

export function shareContent(title, url) {
    if (navigator.share) {
        navigator.share({
            title: title,
            url: url
        }).catch(console.error);
    } else {
        copyToClipboard(url);
    }
}