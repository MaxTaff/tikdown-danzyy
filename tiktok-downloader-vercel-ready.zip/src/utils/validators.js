// utils/validators.js
export function validateUrl(string) {
    try {
        new URL(string);
        // Check if it's a TikTok URL
        const urlObj = new URL(string);
        const validDomains = ['tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'];
        return validDomains.some(domain => urlObj.hostname.includes(domain));
    } catch (_) {
        return false;
    }
}