// utils/helpers.js
export function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function isVideoContent(data) {
    return !Array.isArray(data.images) || data.images.length === 0;
}

export function isPhotoContent(data) {
    return Array.isArray(data.images) && data.images.length > 0;
}