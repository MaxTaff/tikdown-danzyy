// components/LoadingSpinner.js
export function renderLoadingSpinner() {
    const spinnerElement = document.createElement('section');
    spinnerElement.className = 'loading-section';
    spinnerElement.id = 'loadingSection';
    spinnerElement.style.display = 'none';
    spinnerElement.innerHTML = `
        <div class="spinner"></div>
        <p class="loading-text">Mengambil data dari TikTok...</p>
    `;
    return spinnerElement;
}