// components/ImageGallery.js
export function renderImageGallery(imageUrls) {
    const galleryElement = document.createElement('div');
    galleryElement.className = 'image-gallery';
    
    // Show only the first image as preview
    if (imageUrls.length > 0) {
        const imgElement = document.createElement('img');
        imgElement.src = imageUrls[0];
        imgElement.alt = 'Preview';
        imgElement.className = 'preview-image';
        galleryElement.appendChild(imgElement);
    }
    
    return galleryElement;
}