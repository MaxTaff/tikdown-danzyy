// components/MusicPlayer.js
export function renderMusicPlayer(musicData) {
    const musicElement = document.createElement('div');
    musicElement.className = 'music-info';
    
    if (musicData && musicData.title) {
        musicElement.innerHTML = `
            <div class="music-title">${musicData.title}</div>
            <div class="music-author">by ${musicData.author || 'Artis Tidak Diketahui'}</div>
        `;
    }
    
    return musicElement;
}