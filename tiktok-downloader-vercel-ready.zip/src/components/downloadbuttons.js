// components/DownloadButtons.js
import { downloadFile, copyToClipboard, shareContent } from '../services/downloadService.js';

export function renderDownloadButtons(data) {
    const buttonsContainer = document.createElement('div');
    buttonsContainer.className = 'download-buttons';
    
    let buttonsHTML = '';
    
    // Video download button
    if (data.play_url) {
        buttonsHTML += `
            <button class="download-btn" onclick="window.downloadFile('${data.play_url}', 'tiktok-${data.id}.mp4')">
                <i class="fas fa-video"></i> Video HD
            </button>
        `;
    }
    
    // Image download buttons
    if (data.images && data.images.length > 0) {
        data.images.forEach((img, index) => {
            buttonsHTML += `
                <button class="download-btn" onclick="window.downloadFile('${img}', 'tiktok-${data.id}-foto${index+1}.jpg')">
                    <i class="fas fa-image"></i> Foto ${index+1}
                </button>
            `;
        });
    }
    
    // Music download button
    if (data.music && data.music.play_url) {
        buttonsHTML += `
            <button class="download-btn" onclick="window.downloadFile('${data.music.play_url}', 'tiktok-music-${data.music.id}.mp3')">
                <i class="fas fa-music"></i> Audio
            </button>
        `;
    }
    
    // Utility buttons
    buttonsHTML += `
        <button class="download-btn" onclick="window.copyToClipboard('${data.play_url || data.images[0]}')">
            <i class="fas fa-copy"></i> Copy Link
        </button>
        <button class="download-btn" onclick="window.shareContent('${data.desc}', '${data.play_url || data.images[0]}')">
            <i class="fas fa-share-alt"></i> Share
        </button>
    `;
    
    buttonsContainer.innerHTML = buttonsHTML;
    
    // Attach global functions to window for inline handlers
    window.downloadFile = downloadFile;
    window.copyToClipboard = copyToClipboard;
    window.shareContent = shareContent;
    
    return buttonsContainer;
}