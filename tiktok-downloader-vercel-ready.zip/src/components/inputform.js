// components/InputForm.js
export function renderInputForm(onSubmit) {
    const formElement = document.createElement('form');
    formElement.className = 'url-input-form';
    formElement.id = 'downloadForm';
    formElement.innerHTML = `
        <div class="input-wrapper">
            <input 
                type="url" 
                id="tiktokUrl" 
                placeholder="Tempel URL TikTok disini..." 
                required
                autocomplete="off"
            >
            <button type="submit" class="submit-btn" id="downloadBtn">
                <i class="fas fa-download"></i> Download
            </button>
        </div>
        <div id="errorMessage" class="error-message" style="display: none;"></div>
    `;

    formElement.addEventListener('submit', onSubmit);
    
    return formElement;
}