// components/VideoPreview.js
export function renderVideoPreview(videoUrl) {
    const videoElement = document.createElement('video');
    videoElement.className = 'video-player';
    videoElement.src = videoUrl;
    videoElement.controls = true;
    videoElement.setAttribute('preload', 'metadata');
    return videoElement;
}