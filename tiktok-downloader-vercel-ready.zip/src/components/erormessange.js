// components/ErrorMessage.js
export function renderErrorMessage(message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'error-message';
    errorElement.id = 'errorMessage';
    errorElement.textContent = message;
    errorElement.style.display = 'none';
    return errorElement;
}