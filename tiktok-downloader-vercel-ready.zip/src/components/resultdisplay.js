// components/ResultDisplay.js
import { renderVideoPreview } from './VideoPreview.js';
import { renderImageGallery } from './ImageGallery.js';
import { renderMusicPlayer } from './MusicPlayer.js';
import { renderDownloadButtons } from './DownloadButtons.js';
import { formatNumber } from '../utils/helpers.js';

export function renderResultDisplay(data) {
    const resultElement = document.createElement('article');
    resultElement.className = 'result-card';
    
    // Author info
    const authorInfo = document.createElement('div');
    authorInfo.className = 'author-info';
    authorInfo.id = 'authorInfo';
    authorInfo.innerHTML = `
        <img src="${data.author.avatar}" alt="Avatar" class="author-avatar" onerror="this.src='./assets/images/placeholder.jpg';">
        <div class="author-details">
            <h3>${data.author.nickname}</h3>
            <span>${data.author.unique_id}</span>
        </div>
    `;
    
    // Video title
    const titleElement = document.createElement('h2');
    titleElement.className = 'video-title';
    titleElement.id = 'videoTitle';
    titleElement.textContent = data.desc;
    
    // Preview container
    const previewContainer = document.createElement('div');
    previewContainer.className = 'preview-container';
    previewContainer.id = 'previewContainer';
    
    // Render preview based on content type
    if (data.images && data.images.length > 0) {
        previewContainer.appendChild(renderImageGallery(data.images));
    } else if (data.play_url) {
        previewContainer.appendChild(renderVideoPreview(data.play_url));
    }
    
    // Stats grid
    const statsGrid = document.createElement('div');
    statsGrid.className = 'stats-grid';
    statsGrid.id = 'videoStats';
    statsGrid.innerHTML = `
        <div class="stat-item">
            <strong>${formatNumber(data.stats.play_count)}</strong>
            <span>Views</span>
        </div>
        <div class="stat-item">
            <strong>${formatNumber(data.stats.digg_count)}</strong>
            <span>Likes</span>
        </div>
        <div class="stat-item">
            <strong>${formatNumber(data.stats.comment_count)}</strong>
            <span>Komentar</span>
        </div>
        <div class="stat-item">
            <strong>${formatNumber(data.stats.share_count)}</strong>
            <span>Share</span>
        </div>
    `;
    
    // Music info
    const musicInfo = document.createElement('div');
    musicInfo.className = 'music-info';
    musicInfo.id = 'musicInfo';
    if (data.music) {
        musicInfo.innerHTML = `
            <div class="music-title">${data.music.title}</div>
            <div class="music-author">by ${data.music.author}</div>
        `;
    }
    
    // Download buttons
    const downloadButtons = renderDownloadButtons(data);
    downloadButtons.id = 'downloadButtons';
    
    // Append all elements to result card
    resultElement.appendChild(authorInfo);
    resultElement.appendChild(titleElement);
    resultElement.appendChild(previewContainer);
    resultElement.appendChild(statsGrid);
    resultElement.appendChild(musicInfo);
    resultElement.appendChild(downloadButtons);
    
    return resultElement;
}