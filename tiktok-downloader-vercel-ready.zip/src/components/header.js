// components/Header.js
export function renderHeader() {
    const headerElement = document.createElement('header');
    headerElement.className = 'app-header';
    headerElement.innerHTML = `
        <div class="header-content">
            <h1><i class="fab fa-tiktok"></i> TikTok Downloader</h1>
            <p>Unduh video, foto, dan audio tanpa watermark</p>
        </div>
    `;
    return headerElement;
}